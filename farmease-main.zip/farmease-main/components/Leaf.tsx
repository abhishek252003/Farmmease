import React from "react"

const LeafAnimation = () => {
    return(
        <div></div>
    )
}

export default LeafAnimation