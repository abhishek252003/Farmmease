import React from "react";

const Weather = ({ cityName }: any) => {
  return <div></div>;
};

export default Weather;
